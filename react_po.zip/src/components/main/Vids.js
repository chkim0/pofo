function Vids(){
    return(
        <main id='vids' className="myScroll">
        <h1>Vids</h1>
        </main>
    )
}

export default Vids;