import React from "react"
export default function Content() {
    return (
        <main>
            <h1>Content</h1>
        </main>
    )
}