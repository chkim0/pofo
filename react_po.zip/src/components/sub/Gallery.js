import Layout from "../common/Layout";
export default function Gallery() {
    return (
        <Layout name={'Gallery'}>
            <p>Gallery contents</p>
        </Layout>
    );
}